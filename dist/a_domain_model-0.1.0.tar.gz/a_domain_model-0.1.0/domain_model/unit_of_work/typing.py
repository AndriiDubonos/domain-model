from enum import Enum
from typing import TypeVar

UnitTypeBase = TypeVar('UnitTypeBase', bound=Enum)
